package com.example.bitcoin_converter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
